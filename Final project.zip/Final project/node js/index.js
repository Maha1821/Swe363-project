const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require('body-parser');
const session = require("express-session");
require("dotenv").config();

const app = express();
app.use(bodyParser.json());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(
  session({
    secret: process.env.SESSION_SECRET || "default-secret-key", 
    resave: false, 
    saveUninitialized: true, 
    cookie: {
      secure: process.env.NODE_ENV === "production", 
      httpOnly: true, 
      maxAge: 3600000, // 1 hour
    },
  })
);

// MongoDB Connection
mongoose
  .connect("mongodb+srv://Maha1989:Swe363DbProject@Cluster0.aywcc.mongodb.net/Swe363project?retryWrites=true&w=majority&appName=Cluster0")
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("MongoDB connection error:", err));

// Start Server
app.listen(8012, () => console.log("Server running"));

// Models
const Contact = require("./models/Contact");
const User = require("./models/User");
const Book = require("./models/Book");
const Order = require('./models/Order.js');

// Routes for Contact
app.post("/api/contact", async (req, res) => {
  try {
    const { username, email, message } = req.body;
    if (!username || !email || !message) {
      return res.status(400).json({ error: "All fields are required." });
    }
    const contactMessage = new Contact({ username, email, message });
    await contactMessage.save();
    res.status(201).json({ message: "Your message has been sent successfully." });
  } catch (error) {
    console.error("Error saving contact message:", error);
    res.status(500).json({ error: "Failed to send your message. Please try again later." });
  }
});

// Routes for User
app.post("/api/signup", async (req, res) => {
  try {
    const { fullName, contactNumber, email, password, userName, pin } = req.body;
    if (!fullName || !email || !password || !userName || !pin) {
      return res.status(400).json({ error: "All required fields must be filled." });
    }
    const existingUser = await User.findOne({ $or: [{ userName }, { email }] });
    if (existingUser) {
      return res.status(400).json({ error: "Username or email already in use." });
    }
    const newUser = new User({ fullName, contactNumber: contactNumber || null, email, password, role: "User", userName, pin });
    await newUser.save();
    res.status(201).json({ message: "User registered successfully." });
  } catch (error) {
    console.error("Error during user signup:", error);
    res.status(500).json({ error: "Internal server error. Please try again later." });
  }
});

app.post('/api/login', async (req, res) => {
  const { userName, password } = req.body;
  const user = await User.findOne({ userName });
  if (!user || password !== user.password) {
    return res.status(401).json({ message: 'Invalid username or password' });
  }
  req.session.userId = user._id;
  res.status(200).json({ message: 'Login successful', role: user.role });
});

app.post("/update-password", async (req, res) => {
  const { newPassword } = req.body;
  if (!req.session.userId) {
    return res.status(401).json({ message: "Unauthorized. Please log in again." });
  }
  try {
    const user = await User.findById(req.session.userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    user.password = newPassword;
    await user.save();
    res.status(200).json({ message: "Password updated successfully" });
  } catch (error) {
    console.error("Error updating password:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

app.post("/verify-pin", async (req, res) => {
  const { username, pin } = req.body;
  try {
    const user = await User.findOne({ userName: username, pin });
    if (!user) {
      return res.status(401).json({ message: "Invalid username or PIN" });
    }
    req.session.userId = user._id;
    res.status(200).json({ message: "PIN verified successfully" });
  } catch (error) {
    console.error("Error verifying PIN:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Routes for Books
app.post("/api/sell-book", async (req, res) => {
  try {
    const { title, author, genre, condition, price, description, image } = req.body;
    if (!title || !author || !genre || !condition || !price || !description || !image) {
      return res.status(400).json({ error: "All fields, including an image, are required." });
    }
    const newBook = new Book({ author, genre, price, title, condition, image, availability: true, description });
    await newBook.save();
    res.status(201).json({ message: "Book listed successfully!" });
  } catch (error) {
    console.error("Error saving book:", error);
    res.status(500).json({ error: "Failed to save the book. Try again later." });
  }
});

app.get("/api/books", async (req, res) => {
  try {
    const books = await Book.find();
    res.json(books);
  } catch (error) {
    console.error('Error fetching books:', error);
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/books/category/:category", async (req, res) => {
  try {
    const books = await Book.find({ category: req.params.category });
    res.json(books);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Orders
app.post('/api/orders', async (req, res) => {
  try {
    const { email, address, payment } = req.body;
    const newOrder = new Order({ email, address, payment });
    await newOrder.save();
    res.status(200).json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to save order.' });
  }
});

app.get("/api/orders/:email", async (req, res) => {
  try {
    const orders = await Order.find({ email: req.params.email });
    res.status(200).json(orders);
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ error: 'Could not fetch the orders' });
  }
});

// Extra Routes
app.get("/api/contacts", async (req, res) => {
  try {
    const contacts = await Contact.find();
    res.status(200).json(contacts);
  } catch (err) {
    console.error('Error fetching contacts:', err);
    res.status(500).json({ error: 'Could not fetch the contacts' });
  }
});

// Database initialization for MongoDB
const { connectToDb, getDb } = require('./db');
let db;
connectToDb((err) => {
  if (err) {
    console.error("Database connection failed:", err);
  } else {
    db = getDb();
    console.log("Database connected");
  }
});

app.get("/api/book", async (req, res) => {
  if (!db) {
    return res.status(500).json({ error: 'Database not connected' });
  }
  db.collection('Books')
    .find()
    .sort({ Title: 1 })
    .toArray()
    .then((books) => res.status(200).json(books))
    .catch((err) => res.status(500).json({ error: 'Could not fetch the documents' }));
});

app.get("/api/users", async (req, res) => {
  if (!db) {
    return res.status(500).json({ error: 'Database not connected' });
  }
  try {
    const users = await db.collection("users").find({}, { projection: { email: 1, userName: 1 } }).toArray();
    res.status(200).json(users);
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch the users' });
  }
});

app.delete("/api/users/:email", async (req, res) => {
  if (!db) {
    return res.status(500).json({ error: 'Database not connected' });
  }
  try {
    const result = await db.collection("users").deleteOne({ email: req.params.email });
    if (result.deletedCount === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.status(200).json({ message: `User with email ${req.params.email} deleted successfully` });
  } catch (err) {
    res.status(500).json({ error: 'Could not delete the user' });
  }
});
