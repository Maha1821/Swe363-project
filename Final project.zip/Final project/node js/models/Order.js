const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    date: {
      type: Date,
      default: Date.now, 
    },
    email: {
      type: String,
      required: true,
    },
    address: {
      type: String,
      required: true,
    },
    payment: {
      cardNumber: {
        type: String,
        required: true,
      },
      expirationDate: {
        type: String,
        required: true,
      },
      cvv: {
        type: String,
        required: true,
      },
    },
  });
  
module.exports = mongoose.model('order', orderSchema);

