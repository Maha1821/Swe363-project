
// module.exports = mongoose.model("Book", bookSchema);
const mongoose = require('mongoose');

const bookSchema = new mongoose.Schema({
    id: { type: Number, required: true, unique: true },
    title: { type: String, required: true },
    author: { type: String, required: true },
    category: { type: String, required: true },
    condition: { type: String, required: true },
    price: { type: Number, required: true },
    description: String,
    image: { type: String, required: true },
    availability: { type: String, default: 'available' }
});

module.exports = mongoose.model('Book', bookSchema);
