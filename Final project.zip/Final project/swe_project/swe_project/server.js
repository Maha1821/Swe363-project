
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const app = express();

app.use(cors());
app.use(express.json());

// Define Book Schema
const bookSchema = new mongoose.Schema({
    title: String,
    author: String,
    category: String,
    price: Number,
    image: String,
    description: String,
    condition: String,
    availability: String
});

const Book = mongoose.model('Book', bookSchema);

// MongoDB Connection
mongoose
    .connect("mongodb+srv://Maha1989:Swe363DbProject@cluster0.aywcc.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
    .then(async () => {
        console.log("Connected to MongoDB");
        
        // Check if there are any books in the database
        const count = await Book.countDocuments();
        if (count === 0) {
            // Add initial books if database is empty
            await Book.insertMany([
                {
                    title: "A Study in Scarlet",
                    image: "images/book1.jpg",
                    category: "mystery",
                    author: "Conan Doyle",
                    availability: "available",
                    condition: "New",
                    price: 45,
                    description: "A dense yellow miasma swirls in the streets of London..."
                },
                {
                    title: "The sign of four",
                    image: "images/book2.jpg",
                    category: "mystery",
                    author: "Conan Doyle",
                    availability: "Used - Good",
                    condition: "New",
                    price: 40,
                    description: "In this intriguing mystery, Sherlock Holmes..."
                }
            ]);
            console.log("Initial books added to database");
        }
    })
    .catch((err) => console.error("MongoDB connection error:", err));

// Routes
app.get('/api/books', async (req, res) => {
    try {
        const books = await Book.find();
        console.log('Sending books:', books);
        res.json(books);
    } catch (error) {
        console.error('Error fetching books:', error);
        res.status(500).json({ message: error.message });
    }
});

// Test endpoint
app.get('/test', (req, res) => {
    res.json({ message: 'Server is working' });
});

// Start Server
app.listen(8002, () => console.log("Server running on port 8002"));







